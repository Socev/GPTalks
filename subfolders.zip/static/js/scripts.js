function toggleMenu() {
    const menu = document.getElementById('menu');
    menu.classList.toggle('hidden');
}

function toggleLeftbar(forceCollapse) {
    const leftbar = document.getElementById("leftbar");
    if (forceCollapse || leftbar.classList.contains("open")) {
        leftbar.classList.remove("open");
    } else {
        leftbar.classList.add("open");
    }
}

function isLeftbarExpanded() {
    const leftbar = document.getElementById("leftbar");
    return leftbar.classList.contains("open");
}

